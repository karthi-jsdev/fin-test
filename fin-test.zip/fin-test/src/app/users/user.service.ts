import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Subject } from "rxjs";
import { map } from "rxjs/operators";
import { Router } from "@angular/router";

import { User } from "./users.model";

@Injectable({ providedIn: "root" })
export class UsersService {
  private users: User[] = [];
  private postsUpdated = new Subject<User[]>();

  constructor(private http: HttpClient, private router: Router) {}

  getPosts() {
    this.http
      .get<{ message: string; users: any }>("http://localhost:3000/api/users")
      .pipe(
        map(postData => {
          return postData.users.map(user => {
            return {
              name: user.name,
              age: user.age,
              id: user._id
            };
          });
        })
      )
      .subscribe(transformedPosts => {
        this.users = transformedPosts;
        this.postsUpdated.next([...this.users]);
      });
  }

  getPostUpdateListener() {
    return this.postsUpdated.asObservable();
  }

  getPost(id: string) {
    return this.http.get<{ _id: string; name: string; age: number }>(
      "http://localhost:3000/api/users/" + id
    );
  }

  addPost(name: string, age: number) {
    const post: User = { id: null, name: name, age: age };
    this.http
      .post<{ message: string; postId: string }>(
        "http://localhost:3000/api/users",
        post
      )
      .subscribe(responseData => {
        const id = responseData.postId;
        post.id = id;
        this.users.push(post);
        this.postsUpdated.next([...this.users]);
        this.router.navigate(["/"]);
      });
  }

  updatePost(id: string, name: string, age: number) {
    const post: User = { id: id, name: name, age: age };
    this.http
      .put("http://localhost:3000/api/users/" + id, post)
      .subscribe(response => {
        const updatedPosts = [...this.users];
        const oldPostIndex = updatedPosts.findIndex(p => p.id === post.id);
        updatedPosts[oldPostIndex] = post;
        this.users = updatedPosts;
        this.postsUpdated.next([...this.users]);
        this.router.navigate(["/"]);
      });
  }

  deletePost(postId: string) {
    this.http
      .delete("http://localhost:3000/api/users/" + postId)
      .subscribe(() => {
        const updatedPosts = this.users.filter(post => post.id !== postId);
        this.users = updatedPosts;
        this.postsUpdated.next([...this.users]);
      });
  }
}
