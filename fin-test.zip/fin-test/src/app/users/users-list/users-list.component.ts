import { Component, OnInit, OnDestroy } from "@angular/core";
import { Subscription } from 'rxjs';

import { User } from "../users.model";
import { UsersService } from "../user.service";

@Component({
  selector: "app-user-list",
  templateUrl: "./users-list.component.html",
  styleUrls: ["./users-list.component.css"]
})
export class UserListComponent implements OnInit, OnDestroy {
  // users = [
  //   { title: "First User", content: "This is the first post's content" },
  //   { title: "Second User", content: "This is the second post's content" },
  //   { title: "Third User", content: "This is the third post's content" }
  // ];
  users: User[] = [];
  isLoading = false;
  private postsSub: Subscription;

  constructor(public usersService: UsersService) {}

  ngOnInit() {
    this.isLoading = true;
    this.usersService.getPosts();
    this.postsSub = this.usersService.getPostUpdateListener()
      .subscribe((users: User[]) => {
        this.isLoading = false;
        this.users = users;
      });
  }

  onDelete(postId: string) {
    this.usersService.deletePost(postId);
  }

  ngOnDestroy() {
    this.postsSub.unsubscribe();
  }
}
