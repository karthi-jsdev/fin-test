import { Component, OnInit } from "@angular/core";
import { NgForm } from "@angular/forms";
import { ActivatedRoute, ParamMap } from "@angular/router";
import { UsersService } from "../user.service";
import { User } from "../users.model";

@Component({
  selector: "app-users-create",
  templateUrl: "./users-create.component.html",
  styleUrls: ["./users-create.component.css"]
})
export class UserCreateComponent implements OnInit {
  enteredTitle = "";
  enteredContent = "";
  user: User;
  isLoading = false;
  private mode = "create";
  private userId: string;

  constructor(
    public usersService: UsersService,
    public route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.route.paramMap.subscribe((paramMap: ParamMap) => {
      if (paramMap.has("userId")) {
        this.mode = "edit";
        this.userId = paramMap.get("userId");
        this.isLoading = true;
        this.usersService.getPost(this.userId).subscribe(userData => {
          this.isLoading = false;
          this.user = {id: userData._id, name: userData.name, age: userData.age};
        });
      } else {
        this.mode = "create";
        this.userId = null;
      }
    });
  }

  onAddUser(form: NgForm) {
    if (form.invalid) {
      return;
    }
    this.isLoading = true;
    if (this.mode === "create") {
      this.usersService.addPost(form.value.name, form.value.age);
    } else {
      this.usersService.updatePost(
        this.userId,
        form.value.name,
        form.value.age
      );
    }
    form.resetForm();
  }
}
